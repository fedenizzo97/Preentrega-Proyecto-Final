# ProyectoFinal_Grupo4

**_TABLA DE CONTENIDOS_**

  1.- [DESCRIPCIÓN]
  
  2.- [TECNOLOGÍA]
  
  3.- [INSTALACIÓN]
  
  4.- [RUTAS PRINCIPALES]
  
  5.- [PREVIEW]
  
  6.- [AUTORES]
    
**_DESCRIPCIÓN_**
***
Pagina Web con 3 clases:
  ## 1) Clase Autos 
  ## 2) Clase Inmuebles 
  ## 3) Clase Facultad
  
**_TECNOLOGÍA_**
 ***
  *[Python] Versión 3.9.7
  *[Django] Versión 3.0.7
 
 **_INSTALACIÓN_**
 ***
 git clone https://github.com/cancharimmd/ProyectoFinal_Grupo4.git
 
  **_RUTAS PRINCIPALES_**
  *** 
    1.- [INICIO] /AppCoder/inicio
    2.- [AUTOS] /AppCoder/autos
      2.1.- [FORMULARIO AUTOS] /AppCoder/autoFormulario
    3.- [INMUEBLES] /AppCoder/inmuebles
      3.1.- [FORMULARIO INMUEBLES] /AppCoder/inmuebleFormulario
    4.- [FACULTAD] /AppCoder/facultad
      4.1.- [FORMULARIO FACULTAD] /AppCoder/facultadFormulario
    5.- [ADMIN] /admin (Usuario: diego; Password: 123456)
   
  **_PREVIEW_**
  *** 
  
  ![image](https://user-images.githubusercontent.com/50807727/146293252-cce62a85-58f1-4750-a9bd-e0ccc0a5441c.png)
  
  **_AUTORES_**
  *** 
    
  1.- [DIEGO CANCHARI]
  
  2.- [EDITH JORDÁN]
  
  3.- [FEDERICO NIZZO]
  
  4.- [FEDERICO MONTOYA]
