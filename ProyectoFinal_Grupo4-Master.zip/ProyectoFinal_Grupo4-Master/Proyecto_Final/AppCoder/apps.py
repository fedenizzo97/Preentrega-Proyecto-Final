from django.apps import AppConfig


class AppcoderConfig(AppConfig):
    name = 'AppCoder'
