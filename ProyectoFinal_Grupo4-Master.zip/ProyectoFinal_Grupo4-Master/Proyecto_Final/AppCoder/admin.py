from django.contrib import admin
from .models import *

# Register your models here.
# usuario: diego
# password: 123456

admin.site.register(Autos)

admin.site.register(Inmuebles)

admin.site.register(Facultad)